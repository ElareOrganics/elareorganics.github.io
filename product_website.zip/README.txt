How to use this site files
1) Extract the zip.
2) Replace 'placeholder.jpg' with your product images (use same filename or edit HTML).
3) Edit contact details and WhatsApp numbers in contact.html and products.html.
4) To host:
   - Option A: Upload the files to GitHub and enable GitHub Pages (free).
   - Option B: Upload to any static host or your web hosting control panel.
   - Option C: Open index.html locally for a demo.
5) If you want me to customize product names/prices or add more products, tell me the details.
